/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.fizzbuzzmaven;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class FizzBuzz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner lerPalavra = new Scanner(System.in);
        
        System.out.println("Digite o número desejado: ");
        
        String palavra = lerPalavra.nextLine();
        
         try {
        int i = Integer.parseInt(palavra); 
       
        } catch (NumberFormatException e) {
        
        } finally {
        lerPalavra.close(); 
        }
        
        FizzBuzzEsqueleto esqueletoFB = new FizzBuzzEsqueleto();
        esqueletoFB.testeFizzBuzz(Integer.parseInt(palavra));
    }
    
}
