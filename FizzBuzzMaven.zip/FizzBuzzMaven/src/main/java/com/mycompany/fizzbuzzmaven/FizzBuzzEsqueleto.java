/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.fizzbuzzmaven;

/**
 *
 * @author User
 */
public class FizzBuzzEsqueleto {

    public String testeFizzBuzz(int palavraTeste){
        
        
        if(palavraTeste > 0){
            
            if(palavraTeste % 15 == 0){
                System.out.println("FizzBuzz");
            return "FizzBuzz";
            
            }else if(palavraTeste % 3 == 0){
                System.out.println("Fizz");
            return "Fizz";
            
            }else if(palavraTeste % 5 == 0){
                System.out.println("Buzz");
             return "Buzz";
             
            }else System.out.println("Outro número");
                
                return "Número";
        } else 
            System.out.println("Zero");
            return "Zero"; //To change body of generated methods, choose Tools | Templates.
    }
    
}
