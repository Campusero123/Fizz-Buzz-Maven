/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import com.mycompany.fizzbuzzmaven.FizzBuzzEsqueleto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class testeDeFizzBuzz {
    
    
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
     public void testeFB() {
            
            FizzBuzzEsqueleto esqueletoFB = new FizzBuzzEsqueleto();
        
            Assert.assertEquals("Fizz", esqueletoFB.testeFizzBuzz(3));
            Assert.assertEquals("Buzz", esqueletoFB.testeFizzBuzz(5));
            Assert.assertEquals("Número", esqueletoFB.testeFizzBuzz(34));
            Assert.assertEquals("FizzBuzz", esqueletoFB.testeFizzBuzz(15));
            Assert.assertEquals("FizzBuzz", esqueletoFB.testeFizzBuzz(45));
            Assert.assertEquals("Zero", esqueletoFB.testeFizzBuzz(0));
            Assert.assertEquals("Número", esqueletoFB.testeFizzBuzz(98));
        }
}
